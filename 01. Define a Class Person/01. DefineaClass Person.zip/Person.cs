﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01._Define_a_Class_Person
{
    internal class Person
    {
    }
}
