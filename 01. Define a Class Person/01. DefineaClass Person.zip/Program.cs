﻿using System;

namespace _01._Define_a_Class_Person
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
