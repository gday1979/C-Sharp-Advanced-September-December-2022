﻿using System;

namespace _02._Creating_Constructors
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
