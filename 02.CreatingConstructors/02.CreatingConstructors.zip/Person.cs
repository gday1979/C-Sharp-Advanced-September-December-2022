﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _02.CreatingConstructors
{
    internal class Person
    {
    }
}
